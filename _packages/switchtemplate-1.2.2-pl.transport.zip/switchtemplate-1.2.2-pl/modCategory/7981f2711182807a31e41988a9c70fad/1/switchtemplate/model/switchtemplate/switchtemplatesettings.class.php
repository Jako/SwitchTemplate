<?php

class SwitchtemplateSettings extends xPDOSimpleObject
{
}