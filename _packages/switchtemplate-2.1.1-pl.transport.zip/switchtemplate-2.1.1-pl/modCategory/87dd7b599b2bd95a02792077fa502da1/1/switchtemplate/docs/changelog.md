# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.1] - 2026-11-15

### Fixed

- Restore the registered scripts and styles of cached switched templates
- Fix the extension based template switch with disabled `cache_alias_map` and extensions with any number of dots
- Remove unsafe HTML from the settings grid and prevent duplicate setting keys

## [2.1.0] - 2026-09-29

### Added

- Add `Enabled Templates` and `Enabled Contexts` option to restrict template switching

## [2.0.0] - 2023-03-20

### Removed

- AMP Output filtering (because of Guzzle 6 vs. 7 issues in MODX 3 and since [AMP is dead](https://plausible.io/blog/google-amp))
- Remove Guzzle 6

## [1.3.3] - 2022-06-24

### Security

- Update guzzlehttp/guzzle to 6.5.8 for [security reasons](https://github.com/guzzle/guzzle/security/advisories)

## [1.3.2] - 2022-06-10

### Changed

- Update Composer dependencies
- Decrease the timeout in the statistics resolver
- Fix wrong classname

### Security

- Update guzzlehttp/guzzle to 6.5.7 for [security reasons](https://github.com/guzzle/guzzle/security/advisories)

## [1.3.1] - 2022-02-17

### Fixed

- Fix strrpos warning: Offset is greater than the length of haystack string
- Fix PHP notice: Undefined property: SwitchTemplate::$fromCache

## [1.3.0] - 2022-01-11

### Changed

- Code refactoring
- Full MODX 3 compatibility

## [1.2.5] - 2020-12-29

### Fixed

- Bugfix for not found switching extensions

## [1.2.4] - 2020-11-19

### Added

- Add static file support for templates (Thanks to [David Pede](https://github.com/davidpede)) [#10]

## [1.2.3] - 2019-02-23

### Added

- Show debug mode in custom manager page
- System settings tab in custom manager page

### Changed

- Log errors in debug mode only

## [1.2.2] - 2018-02-26

### Fixed

- Bugfix for an empty output type

## [1.2.1] - 2017-12-04

### Added

- Make the extension based template switch work with xRouting, LangRouter and other routing extras
- Enable debug information in the frontend with a system setting and an URL parameter

## [1.2.0] - 2017-09-12

### Added

- Switch the template on base of the extension
- $modx->RegClient methods are executed in switched templates with HTML output
- Filter the page source before output i.e. for AMP output
- Absolute links & images and image width & height attributes in AMP output
- Switched template/chunk name on base of the original template name
- Set the allowed SwitchTemplate modes in a template variable on resource base

## [1.1.1] - 2015-03-12

### Added

- Switch back to default template if the chunk/template is not found
- Template name could be set by placeholder too

## [1.1.0] - 2015-03-10

### Added

- Chunk name for chunk template type could be set by placeholder

## [1.0.1] - 2014-10-21

### Changed

- Processed placeholders are now cached

## [1.0.0] - 2014-09-27

### Added

- Initial public release
