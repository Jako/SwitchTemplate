<?php
require_once(dirname(dirname(__FILE__)) . '/switchtemplatesettings.class.php');

class SwitchtemplateSettings_mysql extends SwitchtemplateSettings{}