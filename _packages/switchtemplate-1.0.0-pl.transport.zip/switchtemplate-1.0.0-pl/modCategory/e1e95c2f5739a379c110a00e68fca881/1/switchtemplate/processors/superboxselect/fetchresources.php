<?php
/**
 * SwitchTemplate
 *
 * Copyright 2014 by Thomas Jakobi <thomas.jakobi@partout.info>
 *
 * @package switchtemplate
 * @subpackage processor
 *
 * Fetch resources processor for SwitchTemplate SuperBoxSelect
 */

$c = $modx->newQuery('modResource');

$c->where(array(
    'deleted' => false,
    'published' => true
));
$c->select(array('id', 'pagetitle'));
$c->sortby('pagetitle', 'ASC');
$resources = $modx->getCollection('modResource', $c);

// Prepare results to ExtJS JSON pattern
$results = array(
    "success" => true,
    "data" => array(),
);

foreach ($resources as $resource) {
    $results['data'][] = array(
        'id' => $resource->get('id'),
        'pagetitle' => $resource->get('pagetitle'),
    );
}

$output = $modx->toJSON($results);;

// Send results
header("Content-type: text/html; charset=UTF-8");
header("Content-Size: " . strlen($output));
echo $output;
